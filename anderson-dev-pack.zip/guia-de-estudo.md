# 📘 Guia de Estudo — Do VS Code ao GitHub (A2D-Dev)

Este guia resume, de forma simples e prática, tudo que você aplicou: Git, GitHub, estrutura de projeto, Prisma + MySQL e documentação.

---

## 1) Git (o “caderno de anotações” do código)
- Iniciar: `git init`
- Adicionar: `git add .` (coloca tudo na fila)
- Salvar checkpoint: `git commit -m "mensagem"`
- Conectar ao GitHub: `git remote add origin <URL>`
- Enviar: `git push -u origin main`

**Dica:** cada commit é uma página do seu histórico. Seja claro nas mensagens.

---

## 2) Estrutura profissional (NestJS + Prisma)
```
src/           # código da aplicação
prisma/        # schema.prisma + migrações
test/          # testes
.env.example   # modelo de variáveis (NÃO subir .env real)
.gitignore     # evita sujeira no repositório
README.md      # manual do projeto
LICENSE        # licença de uso
```
**Regra de ouro:** organização de pastas = projeto fácil de entender.

---

## 3) Prisma + MySQL (DBeaver como cliente)
- `.env`:
  `DATABASE_URL="mysql://root:123456@localhost:3306/api_impacta"`
- `schema.prisma`:
  `provider = "mysql"` e `url = env("DATABASE_URL")`
- Aplicar mudanças no banco:
  `npx prisma migrate dev`

**Dica:** DBeaver é só a “janela” do banco. Quem conecta é o Prisma.

---

## 4) Scripts do projeto
- Desenvolvimento (hot reload): `npm run dev`
- Build: `npm run build`
- Produção (JS compilado): `npm start`
- Testes: `npm run test`

**Lembrete:** `npm run` lista todos os scripts disponíveis.

---

## 5) Documentação (README + banner)
- README explica “o que é, como roda, quais tecnologias”.
- Banner deixa o repositório com cara de portfólio.
- Commits de documentação usam o prefixo `docs:`.

---

## 6) Boas práticas de commit (Conventional)
- `feat:` nova funcionalidade
- `fix:` correção de bug
- `docs:` documentação
- `chore:` manutenção/infra
- `refactor:` melhoria interna

**Ex.:** `feat: cria módulo de usuário`

---

## 7) Rotina de estudo (leve e efetiva)
- 30–60 min/dia de código prático.
- 1 mini-projeto por semana (CRUD simples).
- Sábado: revisão do que aprendeu.
- Domingo: documentar e publicar no GitHub.

**Mantra:** repetir > decorar. Aprender fazendo.

---

## 8) Checklist rápido (para qualquer projeto)
1. `git init`
2. `.gitignore` + `.env.example` prontos
3. `README.md` com instruções
4. `git add . && git commit -m "chore: estrutura inicial"`
5. Repositório no GitHub
6. `git remote add origin <URL> && git push -u origin main`
7. Conferir no GitHub
